package com.example.moviematchv2;

public class PosterURLs {
    private String original;

    public PosterURLs(String original) {
        this.original = original;
    }

    public String getOriginal() {
        return original;
    }
}
